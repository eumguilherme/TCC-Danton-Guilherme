<DOCTYPE HTML>
<html>
    <head>
        <title>Index</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/indexAdm.css">
    </head>
    <body>
        <?php
            // Inicia a sessão do usuário
            session_start();

            // Verifica se o usuário está logado
            if (!isset($_SESSION["id"])) {
                // O usuário não está logado, redireciona para a página de login
                header("Location: login.php");
                exit();
            }
        ?>

        <nav class="navbar">
            <div class="navbar-left">
                <span class="navbar-brand">Horas+</span>
            </div>
            <div class="navbar-right">
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a href="index.php" class="nav-link">Página Inicial</a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">Perfil</a>
                </li>
                <li class="nav-item">
                    <a href="logout.php" class="nav-link">Sair</a>
                </li>
                </ul>
            </div>
        </nav>

        <div class="topo">
            <button class="button voltar">Voltar</button>
            <h1 class="titulo">Lista de Semestres</h1>
            <a href="#" class="button cadastro">Cadastrar Novo Semestre</a>
        </div>

        <div class="dropdown">
            <h2>Escolha o semestre</h2>
            <button class="dropbtn">Semestre</button>
        <div class="dropdown-content">
            <a href="#">2023-1</a>
            <a href="#">2023-2</a>
            <a href="#">2024-1</a>
            <a href="#">2024-2</a>
        </div>
        </div>

    </body>
</html>