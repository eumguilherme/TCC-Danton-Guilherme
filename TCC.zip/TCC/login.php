<!DOCTYPE html>
<html>
	<head>
		<title>Login</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<link rel="stylesheet" href="css/login.css">
	</head>
	<body>
		<form method="post" action="auth.php">
			<h1>Horas+</h1>
			<h2>Login</h2>
			<label for="matricula">Matrícula:</label>
			<input type="text" id="matricula" name="matricula">
			<label for="senha">Senha:</label>
			<input type="password" id="senha" name="senha">
			<input type="submit" value="Entrar">
		</form>
		<?php
			// Inicia a sessão do usuário

			session_start();
			// Verifica se existe uma mensagem de erro para exibir
			if (isset($_SESSION["login_error"])) {

				// Exibe a mensagem de erro e remove da sessão
				echo "<p class='error'>{$_SESSION['login_error']}</p>";
				unset($_SESSION["login_error"]);
			}
		?>
	</body>
</html>
